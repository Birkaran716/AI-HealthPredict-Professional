"""Professional Flask interface around the original unchanged model files."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from flask import Flask, abort, render_template, request
from backend.database import db
from backend.history import get_history
from backend.models import Patient, Prediction

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "pkl files"
METRICS_FILE = BASE_DIR / "model_metrics.json"
INSTANCE_DIR = BASE_DIR / "instance"
DATABASE_PATH = INSTANCE_DIR / "healthpredict.db"
INSTANCE_DIR.mkdir(exist_ok=True)

app = Flask(
    __name__,
    template_folder=str(BASE_DIR / "templates"),
    static_folder=str(BASE_DIR / "static"),
)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DATABASE_PATH.as_posix()}"

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

app.config["MAX_CONTENT_LENGTH"] = 64 * 1024

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)


def number_field(
    name: str,
    label: str,
    minimum: float,
    maximum: float,
    *,
    step: str = "any",
    integer: bool = False,
    hint: str | None = None,
    group: str = "Clinical measurements",
) -> dict[str, Any]:
    return {
        "name": name,
        "label": label,
        "kind": "number",
        "minimum": minimum,
        "maximum": maximum,
        "step": "1" if integer else step,
        "integer": integer,
        "hint": hint or f"Supported range: {minimum:g} to {maximum:g}",
        "group": group,
    }


def select_field(
    name: str,
    label: str,
    options: list[tuple[int, str]],
    *,
    hint: str | None = None,
    group: str = "Clinical measurements",
) -> dict[str, Any]:
    return {
        "name": name,
        "label": label,
        "kind": "select",
        "options": [{"value": value, "label": text} for value, text in options],
        "hint": hint,
        "group": group,
    }


def request_payload() -> Any:
    return request.get_json(silent=True) or request.form


def save_prediction_with_patient(
    disease_slug: str,
    result: dict[str, Any],
    submitted_data: dict[str, str],
):
    payload = request_payload()
    full_name = str(payload.get("full_name", "")).strip()
    email = str(payload.get("email", "")).strip()
    phone = str(payload.get("phone", "")).strip()
    patient_gender = str(payload.get("patient_gender", "")).strip()
    model_age = submitted_data.get("age") or submitted_data.get("Age")

    if not full_name or not patient_gender:
        raise ValueError("Patient name and gender are required.")

    parsed_age = int(float(model_age)) if model_age else None

    patient = Patient(
        full_name=full_name,
        email=email if email else None,
        phone=phone if phone else None,
        age=parsed_age,
        gender=patient_gender,
    )
    db.session.add(patient)
    db.session.flush()

    prediction = Prediction(
        patient_id=patient.id,
        disease=disease_slug,
        prediction=result["label"],
        confidence=result["confidence"],
        input_data=json.dumps(submitted_data),
    )
    db.session.add(prediction)
    db.session.commit()

    return patient, prediction


BREAST_MEAN_FIELDS = [
    number_field("radius_mean", "Radius mean", 6.981, 28.11, group="Mean measurements"),
    number_field("texture_mean", "Texture mean", 9.71, 39.28, group="Mean measurements"),
    number_field("perimeter_mean", "Perimeter mean", 43.79, 188.5, group="Mean measurements"),
    number_field("area_mean", "Area mean", 143.5, 2501, group="Mean measurements"),
    number_field("smoothness_mean", "Smoothness mean", 0.05263, 0.1634, group="Mean measurements"),
    number_field("compactness_mean", "Compactness mean", 0.01938, 0.3454, group="Mean measurements"),
    number_field("concavity_mean", "Concavity mean", 0, 0.4268, group="Mean measurements"),
    number_field("concave points_mean", "Concave points mean", 0, 0.2012, group="Mean measurements"),
    number_field("symmetry_mean", "Symmetry mean", 0.106, 0.304, group="Mean measurements"),
    number_field("fractal_dimension_mean", "Fractal dimension mean", 0.04996, 0.09744, group="Mean measurements"),
]

BREAST_SE_FIELDS = [
    number_field("radius_se", "Radius SE", 0.1115, 2.873, group="Standard error measurements"),
    number_field("texture_se", "Texture SE", 0.3602, 4.885, group="Standard error measurements"),
    number_field("perimeter_se", "Perimeter SE", 0.757, 21.98, group="Standard error measurements"),
    number_field("area_se", "Area SE", 6.802, 542.2, group="Standard error measurements"),
    number_field("smoothness_se", "Smoothness SE", 0.001713, 0.03113, group="Standard error measurements"),
    number_field("compactness_se", "Compactness SE", 0.002252, 0.1354, group="Standard error measurements"),
    number_field("concavity_se", "Concavity SE", 0, 0.396, group="Standard error measurements"),
    number_field("concave points_se", "Concave points SE", 0, 0.05279, group="Standard error measurements"),
    number_field("symmetry_se", "Symmetry SE", 0.007882, 0.07895, group="Standard error measurements"),
    number_field("fractal_dimension_se", "Fractal dimension SE", 0.0008948, 0.02984, group="Standard error measurements"),
]

BREAST_WORST_FIELDS = [
    number_field("radius_worst", "Radius worst", 7.93, 36.04, group="Worst measurements"),
    number_field("texture_worst", "Texture worst", 12.02, 49.54, group="Worst measurements"),
    number_field("perimeter_worst", "Perimeter worst", 50.41, 251.2, group="Worst measurements"),
    number_field("area_worst", "Area worst", 185.2, 4254, group="Worst measurements"),
    number_field("smoothness_worst", "Smoothness worst", 0.07117, 0.2226, group="Worst measurements"),
    number_field("compactness_worst", "Compactness worst", 0.02729, 1.058, group="Worst measurements"),
    number_field("concavity_worst", "Concavity worst", 0, 1.252, group="Worst measurements"),
    number_field("concave points_worst", "Concave points worst", 0, 0.291, group="Worst measurements"),
    number_field("symmetry_worst", "Symmetry worst", 0.1565, 0.6638, group="Worst measurements"),
    number_field("fractal_dimension_worst", "Fractal dimension worst", 0.05504, 0.2075, group="Worst measurements"),
]


DISEASES: dict[str, dict[str, Any]] = {
    "heart": {
        "title": "Heart Disease Screening",
        "short_title": "Heart Disease",
        "icon": "🫀",
        "description": "Enter cardiovascular measurements used by the existing classification model.",
        "model_file": "heart_disease2.pkl",
        "button": "Analyze heart indicators",
        "positive_values": {1},
        "labels": {0: "Lower model indication of heart disease", 1: "Higher model indication of heart disease"},
        "fields": [
            number_field("age", "Age", 18, 100, integer=True, group="Patient information"),
            select_field("sex", "Sex code used by the dataset", [(0, "Female"), (1, "Male")], group="Patient information"),
            select_field("cp", "Chest pain type", [(0, "Typical angina"), (1, "Atypical angina"), (2, "Non-anginal pain"), (3, "Asymptomatic")]),
            number_field("trestbps", "Resting blood pressure (mm Hg)", 80, 220, integer=True),
            number_field("chol", "Serum cholesterol (mg/dL)", 100, 650, integer=True),
            select_field("fbs", "Fasting blood sugar above 120 mg/dL", [(0, "No"), (1, "Yes")]),
            select_field("restecg", "Resting ECG result", [(0, "Normal"), (1, "ST-T wave abnormality"), (2, "Left ventricular hypertrophy")]),
            number_field("thalach", "Maximum heart rate achieved", 50, 230, integer=True),
            select_field("exang", "Exercise-induced angina", [(0, "No"), (1, "Yes")]),
            number_field("oldpeak", "ST depression (oldpeak)", 0, 7, step="0.1"),
            select_field("slope", "Peak exercise ST slope", [(0, "Downsloping"), (1, "Flat"), (2, "Upsloping")]),
            select_field("ca", "Major vessels visible by fluoroscopy", [(0, "0"), (1, "1"), (2, "2"), (3, "3"), (4, "4")]),
            select_field("thal", "Thalassemia result", [(0, "Unknown / not recorded"), (1, "Fixed defect"), (2, "Normal"), (3, "Reversible defect")]),
        ],
    },
    "diabetes": {
        "title": "Diabetes Screening",
        "short_title": "Diabetes",
        "icon": "🩸",
        "description": "Enter the health measurements expected by the existing diabetes classifier.",
        "model_file": "diabities.pkl",
        "button": "Analyze diabetes indicators",
        "positive_values": {1},
        "labels": {0: "Lower model indication of diabetes", 1: "Higher model indication of diabetes"},
        "fields": [
            number_field("Pregnancies", "Number of pregnancies", 0, 20, integer=True, group="Patient information"),
            number_field("Glucose", "Glucose level", 40, 220),
            number_field("BloodPressure", "Blood pressure", 20, 140),
            number_field("SkinThickness", "Skin thickness", 5, 110),
            number_field("Insulin", "Insulin level", 10, 900),
            number_field("BMI", "Body mass index (BMI)", 10, 75, step="0.1"),
            number_field("DiabetesPedigreeFunction", "Diabetes pedigree function", 0.01, 3, step="0.001"),
            number_field("Age", "Age", 18, 100, integer=True, group="Patient information"),
        ],
    },
    "liver": {
        "title": "Liver Disease Screening",
        "short_title": "Liver Disease",
        "icon": "🧪",
        "description": "Enter liver-function measurements used by the existing classification model.",
        "model_file": "lever model.pkl",
        "button": "Analyze liver indicators",
        "positive_values": {0},
        "labels": {0: "Higher model indication of liver disease", 1: "Lower model indication of liver disease"},
        "fields": [
            number_field("Age", "Age", 1, 100, integer=True, group="Patient information"),
            select_field("Gender", "Gender code used by the dataset", [(0, "Female"), (1, "Male")], group="Patient information"),
            number_field("Total_Bilirubin", "Total bilirubin", 0.1, 80, step="0.1"),
            number_field("Direct_Bilirubin", "Direct bilirubin", 0.1, 25, step="0.1"),
            number_field("Alkaline_Phosphotase", "Alkaline phosphatase", 50, 2200),
            number_field("Alamine_Aminotransferase", "Alanine aminotransferase", 5, 2100),
            number_field("Aspartate_Aminotransferase", "Aspartate aminotransferase", 5, 5000),
            number_field("Total_Protiens", "Total proteins", 2, 11, step="0.1"),
            number_field("Albumin", "Albumin", 0.5, 7, step="0.1"),
            number_field("Albumin_and_Globulin_Ratio", "Albumin and globulin ratio", 0.1, 4, step="0.01"),
        ],
    },
    "breast": {
        "title": "Breast Cancer Pattern Screening",
        "short_title": "Breast Cancer",
        "icon": "🎗️",
        "description": "Enter diagnostic measurements expected by the unchanged serialized SVM model.",
        "model_file": "BREAST CANCER.pkl",
        "button": "Analyze diagnostic pattern",
        "positive_values": {1},
        "labels": {0: "Benign pattern predicted by the model", 1: "Malignant pattern predicted by the model"},
        "experimental": True,
        "notice": "Experimental module: the original model expects specimen ID and does not include its preprocessing pipeline. Treat this result only as a software demonstration.",
        "fields": [
            number_field("id", "Specimen ID", 1, 999999999, integer=True, hint="Required only because the unchanged original model expects this feature.", group="Specimen information"),
            *BREAST_MEAN_FIELDS,
            *BREAST_SE_FIELDS,
            *BREAST_WORST_FIELDS,
        ],
    },
}


def load_model(filename: str) -> Any:
    model_path = MODEL_DIR / filename
    if not model_path.is_file():
        raise FileNotFoundError(f"Required model file was not found: {model_path}")
    model = joblib.load(model_path)
    logger.info("Loaded model: %s", filename)
    return model


MODELS = {slug: load_model(config["model_file"]) for slug, config in DISEASES.items()}


def validate_model_dimensions() -> None:
    for slug, model in MODELS.items():
        expected = len(DISEASES[slug]["fields"])
        actual = getattr(model, "n_features_in_", expected)
        if int(actual) != expected:
            raise RuntimeError(f"{slug} model expects {actual} features; the form defines {expected}.")


validate_model_dimensions()


def parse_form(config: dict[str, Any]) -> tuple[np.ndarray | None, dict[str, str], dict[str, str]]:
    values: list[float] = []
    errors: dict[str, str] = {}
    submitted: dict[str, str] = {}

    payload = request_payload()
    for field in config["fields"]:
        name = field["name"]
        raw_value = str(payload.get(name, "")).strip()
        submitted[name] = raw_value
        if raw_value == "":
            errors[name] = "This field is required."
            continue

        try:
            if field["kind"] == "select":
                value = int(raw_value)
                if value not in {option["value"] for option in field["options"]}:
                    raise ValueError
            elif field.get("integer"):
                numeric_value = float(raw_value)
                if not numeric_value.is_integer():
                    errors[name] = "Enter a whole number."
                    continue
                value = int(numeric_value)
            else:
                value = float(raw_value)

            if field["kind"] == "number" and not field["minimum"] <= value <= field["maximum"]:
                errors[name] = f"Enter a value from {field['minimum']:g} to {field['maximum']:g}."
                continue
            values.append(float(value))
        except (TypeError, ValueError):
            errors[name] = "Enter a valid value."

    if errors:
        return None, errors, submitted
    return np.asarray([values], dtype=float), errors, submitted


def predict(slug: str, data: np.ndarray) -> dict[str, Any]:
    config = DISEASES[slug]
    model = MODELS[slug]
    prediction = int(np.asarray(model.predict(data)).reshape(-1)[0])
    confidence = None

    predict_proba = getattr(model, "predict_proba", None)
    if callable(predict_proba):
        try:
            probabilities = np.asarray(predict_proba(data))[0]
            classes = list(getattr(model, "classes_", range(len(probabilities))))
            confidence = round(float(probabilities[classes.index(prediction)]) * 100, 1)
        except (AttributeError, IndexError, ValueError):
            logger.warning("Confidence unavailable for %s model", slug)

    is_positive = prediction in config["positive_values"]
    return {
        "code": prediction,
        "label": config["labels"].get(prediction, f"Model class {prediction}"),
        "confidence": confidence,
        "tone": "attention" if is_positive else "reassuring",
        "message": "The model found a higher disease-associated pattern in the supplied values." if is_positive else "The model found a lower disease-associated pattern in the supplied values.",
    }


def prediction_page(slug: str):
    config = DISEASES.get(slug)
    if config is None:
        abort(404)

    result = None
    errors: dict[str, str] = {}
    submitted: dict[str, str] = {}
    general_error = None

    if request.method == "POST":
        data, errors, submitted = parse_form(config)

        if data is not None:
            try:
                result = predict(
                    slug, data
                )
                save_prediction_with_patient(
                    slug, result, submitted
                )
            except Exception:
                db.session.rollback()
                logger.exception("Prediction failed for model: %s", slug)
                result = None
                general_error = "The prediction could not be saved. Please try again."

    groups: list[dict[str, Any]] = []
    for field in config["fields"]:
        group = next((item for item in groups if item["name"] == field["group"]), None)
        if group is None:
            group = {"name": field["group"], "fields": []}
            groups.append(group)
        group["fields"].append(field)

    return render_template(
        "prediction.html",
        disease_slug=slug,
        disease=config,
        groups=groups,
        result=result,
        errors=errors,
        submitted=submitted,
        general_error=general_error,
    )


def load_reported_metrics() -> dict[str, Any]:
    with METRICS_FILE.open("r", encoding="utf-8") as metrics_file:
        metrics = json.load(metrics_file)
    rows = metrics["models"]
    metrics["average_accuracy"] = round(sum(item["accuracy"] for item in rows) / len(rows), 2)
    metrics["best_model"] = max(rows, key=lambda item: item["accuracy"])
    return metrics


@app.after_request
def add_security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self'; img-src 'self' data:; script-src 'self'; base-uri 'self'; form-action 'self'"
    if request.endpoint != "static":
        response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/")
def home():
    return render_template("index.html", diseases=DISEASES)

@app.get("/api/history")
def prediction_history():

    return {
        "success": True,
        "history": get_history()
    }

@app.get("/history")
def history_page():
    return render_template("history.html")

@app.route("/heart", methods=["GET", "POST"])
def heart():
    return prediction_page("heart")


@app.route("/diabetes", methods=["GET", "POST"])
def diabetes():
    return prediction_page("diabetes")


@app.route("/liver", methods=["GET", "POST"])
def liver():
    return prediction_page("liver")


@app.route("/breast", methods=["GET", "POST"])
def breast():
    return prediction_page("breast")


@app.get("/model-performance")
def model_performance():
    return render_template("model_performance.html", metrics=load_reported_metrics())


@app.get("/health")
def health():
    return {"status": "ok", "models_loaded": sorted(MODELS.keys())}


@app.post("/api/predict/<disease_slug>")
def api_prediction(disease_slug):

    config = DISEASES.get(
        disease_slug
    )


    if config is None:

        return {

            "success": False,

            "message":
            "Disease model not found."

        }, 404


    data, errors, submitted = parse_form(
        config
    )


    if errors:

        return {

            "success": False,

            "errors": errors

        }, 400


    try:

        result = predict(
            disease_slug,
            data
        )


        patient, prediction = (
            save_prediction_with_patient(

                disease_slug,

                result,

                submitted

            )
        )


        return {

            "success": True,

            "patient": {

                "id": patient.id,

                "name": patient.full_name

            },

            "disease": disease_slug,

            "prediction_id": prediction.id,

            "result": result

        }, 200


    except Exception:

        db.session.rollback()

        logger.exception(
            "API prediction failed: %s",
            disease_slug
        )


        return {

            "success": False,

            "message":
            "Prediction could not be completed."

        }, 500


@app.errorhandler(404)
def not_found(_error):
    return render_template(
        "error.html",
        code=404,
        message="The requested page was not found."
    ), 404



@app.errorhandler(413)
def request_too_large(_error):
    return render_template("error.html", code=413, message="The submitted request was too large."), 413


@app.errorhandler(500)
def server_error(_error):
    logger.error("Unhandled application error")
    return render_template("error.html", code=500, message="An unexpected error occurred."), 500

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.getenv("PORT", "5000")),
        debug=os.getenv("FLASK_DEBUG") == "1",
    )
