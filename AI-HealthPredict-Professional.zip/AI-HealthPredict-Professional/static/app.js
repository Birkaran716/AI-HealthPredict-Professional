```javascript
/*
 * ==========================================
 * PREDICTION FORM
 * ==========================================
 */

const form = document.querySelector("#prediction-form");

if (form) {

    const disease = form.dataset.disease;

    const resultBox =
        document.querySelector("#api-result");

    const resultTitle =
        document.querySelector("#api-result-title");

    const resultMessage =
        document.querySelector("#api-result-message");

    const confidenceBox =
        document.querySelector("#api-confidence");

    const confidenceValue =
        document.querySelector("#api-confidence-value");

    const errorBox =
        document.querySelector("#api-message");

    const submitButton =
        form.querySelector('button[type="submit"]');


    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        errorBox.hidden = true;
        resultBox.hidden = true;


        if (!form.checkValidity()) {

            form.reportValidity();

            return;
        }


        const originalButtonText =
            submitButton.textContent;


        submitButton.disabled = true;

        submitButton.textContent =
            "Analyzing...";


        try {

            const response = await fetch(
                `/api/predict/${disease}`,
                {
                    method: "POST",

                    body: new FormData(form),

                    headers: {
                        Accept: "application/json"
                    }
                }
            );


            const data =
                await response.json();


            if (!response.ok) {

                if (data.errors) {

                    errorBox.textContent =
                        "Please check the entered values and try again.";

                } else {

                    errorBox.textContent =
                        data.message ||
                        "Prediction failed.";
                }

                errorBox.hidden = false;

                return;
            }


            const result =
                data.result;


            resultBox.className =
                `result-card ${result.tone}`;


            resultTitle.textContent =
                result.label;


            resultMessage.textContent =
                result.message;


            if (result.confidence !== null) {

                confidenceValue.textContent =
                    `${result.confidence}%`;

                confidenceBox.hidden = false;

            } else {

                confidenceBox.hidden = true;

            }


            resultBox.hidden = false;


            resultBox.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        } catch (error) {

            console.error(error);


            errorBox.textContent =
                "Unable to connect to the backend. Make sure Flask is running.";


            errorBox.hidden = false;


        } finally {

            submitButton.disabled = false;

            submitButton.textContent =
                originalButtonText;

        }

    });

}






/*
 * ==========================================
 * PREDICTION HISTORY
 * ==========================================
 */

const historyBody =
    document.querySelector("#history-body");


if (historyBody) {

    loadPredictionHistory();

}


async function loadPredictionHistory() {

    const loading =
        document.querySelector("#history-loading");

    const error =
        document.querySelector("#history-error");

    const empty =
        document.querySelector("#history-empty");

    const content =
        document.querySelector("#history-content");


    try {

        const response =
            await fetch(
                "/api/history",
                {
                    method: "GET",

                    headers: {
                        Accept: "application/json"
                    }
                }
            );


        if (!response.ok) {

            throw new Error(
                "Could not load history"
            );

        }


        const data =
            await response.json();


        loading.hidden = true;


        if (
            !data.success ||
            !data.history ||
            data.history.length === 0
        ) {

            empty.hidden = false;

            return;
        }


        historyBody.innerHTML = "";


        data.history.forEach(item => {

            const row =
                document.createElement("tr");


            const date =
                formatDate(item.created_at);


            const disease =
                formatDisease(item.disease);


            const confidence =
                item.confidence !== null &&
                item.confidence !== undefined
                    ? `${item.confidence}%`
                    : "N/A";


            row.innerHTML = `

                <td>${item.id}</td>

                <td>${item.patient_name}</td>

                <td>${item.created_at}</td>

                <td>${item.disease}</td>

                <td>${item.prediction}</td>

                <td>
                    ${
                        item.confidence
                            ? item.confidence + "%"
                            : "N/A"
                    }
                </td>

            `;


            historyBody.appendChild(row);

        });


        content.hidden = false;


    } catch (error) {

        console.error(
            "History error:",
            error
        );


        loading.hidden = true;

        error.hidden = false;

    }

}


/*
 * Format disease name
 */

function formatDisease(name) {

    const diseaseNames = {

        heart: "Heart Disease",

        diabetes: "Diabetes",

        liver: "Liver Disease",

        breast: "Breast Cancer"

    };


    return diseaseNames[name] ||
        name
            .replaceAll("_", " ")
            .replace(/\b\w/g, letter =>
                letter.toUpperCase()
            );

}


/*
 * Format date
 */

function formatDate(value) {

    if (!value) {

        return "Unknown";

    }


    const date =
        new Date(value);


    if (isNaN(date.getTime())) {

        return value;

    }


    return date.toLocaleString();

}

