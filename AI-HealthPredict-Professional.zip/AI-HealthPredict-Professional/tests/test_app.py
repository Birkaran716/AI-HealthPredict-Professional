from __future__ import annotations

import pytest

from app import app
from backend.models import Prediction


@pytest.fixture()
def client():
    app.config.update(TESTING=True)
    with app.test_client() as test_client:
        yield test_client


@pytest.mark.parametrize(
    "path",
    ["/", "/heart", "/diabetes", "/liver", "/breast", "/model-performance", "/history", "/health"],
)
def test_public_pages_load(client, path):
    response = client.get(path)
    assert response.status_code == 200


def test_health_reports_all_models(client):
    response = client.get("/health")
    assert response.get_json() == {
        "status": "ok",
        "models_loaded": ["breast", "diabetes", "heart", "liver"],
    }


def test_invalid_heart_submission_shows_validation(client):
    response = client.post("/heart", data={"age": "not-a-number"})
    assert response.status_code == 200
    assert b"Please correct the highlighted" in response.data
    assert b"Enter a valid value" in response.data


def test_valid_heart_submission_returns_result(client):
    response = client.post(
        "/heart",
        data={
            "full_name": "Test User",
            "patient_age": "52",
            "patient_gender": "Other",
            "age": "52",
            "sex": "1",
            "cp": "0",
            "trestbps": "125",
            "chol": "212",
            "fbs": "0",
            "restecg": "1",
            "thalach": "168",
            "exang": "0",
            "oldpeak": "1",
            "slope": "2",
            "ca": "2",
            "thal": "3",
        },
    )
    assert response.status_code == 200
    assert b"Model screening result" in response.data


def test_valid_diabetes_submission_returns_result(client):
    response = client.post(
        "/diabetes",
        data={
            "full_name": "Test User",
            "patient_age": "50",
            "patient_gender": "Other",
            "Pregnancies": "6",
            "Glucose": "148",
            "BloodPressure": "72",
            "SkinThickness": "35",
            "Insulin": "169.5",
            "BMI": "33.6",
            "DiabetesPedigreeFunction": "0.627",
            "Age": "50",
        },
    )
    assert response.status_code == 200
    assert b"Model screening result" in response.data


def test_valid_liver_submission_returns_result(client):
    response = client.post(
        "/liver",
        data={
            "full_name": "Test User",
            "patient_age": "65",
            "patient_gender": "Other",
            "Age": "65",
            "Gender": "0",
            "Total_Bilirubin": "0.7",
            "Direct_Bilirubin": "0.1",
            "Alkaline_Phosphotase": "187",
            "Alamine_Aminotransferase": "16",
            "Aspartate_Aminotransferase": "18",
            "Total_Protiens": "6.8",
            "Albumin": "3.3",
            "Albumin_and_Globulin_Ratio": "0.9",
        },
    )
    assert response.status_code == 200
    assert b"Model screening result" in response.data


def test_json_prediction_is_saved_and_visible_in_history(client):
    payload = {
        "full_name": "API User",
        "patient_age": "52",
        "patient_gender": "Other",
        "age": "52",
        "sex": "1",
        "cp": "0",
        "trestbps": "125",
        "chol": "212",
        "fbs": "0",
        "restecg": "1",
        "thalach": "168",
        "exang": "0",
        "oldpeak": "1",
        "slope": "2",
        "ca": "2",
        "thal": "3",
    }
    with app.app_context():
        before = Prediction.query.count()

    response = client.post("/api/predict/heart", json=payload)

    assert response.status_code == 200
    assert response.get_json()["success"] is True
    with app.app_context():
        assert Prediction.query.count() == before + 1


def test_prediction_without_patient_details_is_rejected(client):
    response = client.post(
        "/api/predict/heart",
        data={"age": "52"},
    )

    assert response.status_code == 400
    assert response.get_json()["success"] is False


def test_unknown_page_uses_custom_error_page(client):
    response = client.get("/missing-page")
    assert response.status_code == 404
    assert b"The requested page was not found" in response.data
