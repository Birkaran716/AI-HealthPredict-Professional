import numpy as np


def make_prediction(model, values):
    # Convert input into NumPy array
    data = np.asarray([values], dtype=float)

    # Make prediction
    prediction = int(model.predict(data)[0])

    # Confidence
    confidence = None

    if hasattr(model, "predict_proba"):
        try:
            probabilities = model.predict_proba(data)[0]

            classes = list(model.classes_)

            index = classes.index(prediction)

            confidence = round(
                float(probabilities[index]) * 100,
                1
            )

        except Exception:
            confidence = None

    return prediction, confidence