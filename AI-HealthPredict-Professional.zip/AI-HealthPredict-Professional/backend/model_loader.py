import joblib
from pathlib import Path


# Project folder
BASE_DIR = Path(__file__).resolve().parent.parent

# Model folder
MODEL_DIR = BASE_DIR / "pkl files"


def load_model(filename):
    model_path = MODEL_DIR / filename

    if not model_path.exists():
        raise FileNotFoundError(
            f"Model not found: {model_path}"
        )

    return joblib.load(model_path)