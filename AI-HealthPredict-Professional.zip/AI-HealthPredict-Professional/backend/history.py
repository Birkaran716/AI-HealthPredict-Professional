from backend.models import Prediction


def get_history():

    predictions = Prediction.query.order_by(
        Prediction.created_at.desc()
    ).all()

    result = []

    for item in predictions:

        patient = item.patient

        result.append({

            "id": item.id,

            "patient_name": patient.full_name if patient else "Unknown",

            "email": patient.email if patient else None,

            "phone": patient.phone if patient else None,

            "disease": item.disease,

            "prediction": item.prediction,

            "confidence": item.confidence,

            "created_at": item.created_at.strftime(
                "%d %B %Y, %I:%M %p"
            )

        })

    return result