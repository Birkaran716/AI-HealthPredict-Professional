def check_values(values, expected_count):
    if len(values) != expected_count:
        return False, "Wrong number of input values."

    for value in values:
        try:
            float(value)
        except ValueError:
            return False, "All values must be numbers."

    return True, "Valid"