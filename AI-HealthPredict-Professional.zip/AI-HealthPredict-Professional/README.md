# AI HealthPredict

AI HealthPredict is an educational Flask application that connects four existing serialized machine-learning classifiers to a responsive and validated web interface.

## Important scope

This project is a software and machine-learning demonstration. It is not clinically validated and must not be used for medical diagnosis, treatment, or emergency decisions.

The four original `.pkl` model files are preserved unchanged. The professional upgrade improves the application around them: paths, validation, result wording, accessibility, privacy, error handling, testing, documentation, and deployment readiness.

## Features

- Heart disease, diabetes, liver disease, and breast-cancer pattern demos
- Portable model loading on Windows, macOS, and Linux
- Server-side range and category validation
- Human-readable results instead of raw `0` and `1` values
- Classifier confidence when the original model supports `predict_proba`
- Responsive and keyboard-accessible interface
- Dynamic performance dashboard backed by JSON
- Custom errors, security headers, no-cache health responses, and `/health` diagnostics
- Automated Flask route and prediction tests

## Known model limitations

- The model files were not retrained or modified.
- The training notebooks and preprocessing objects are not included.
- The breast-cancer SVM expects a specimen ID and does not include its original preprocessing pipeline. Its page is therefore marked experimental.
- Performance values are transcribed from the included notebook-result screenshots and are not independently reproducible from this repository.
- The screenshots calculate their reported AUC values from hard predictions, not prediction probabilities. The dashboard labels them accordingly.

## Project structure

```text
AI-HealthPredict-Professional/
├── app.py
├── model_metrics.json
├── requirements.txt
├── requirements-dev.txt
├── Procfile
├── datasets/
├── pkl files/                 # Original unchanged model files
├── static/
│   └── style.css
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── prediction.html
│   ├── model_performance.html
│   └── error.html
└── tests/
    └── test_app.py
```

## Local setup

Python 3.11 or 3.12 is recommended.

### Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
python app.py
```

### macOS or Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Tests

```bash
python -m pytest -q
```

## Production command

```bash
gunicorn app:app
```

The application reads the `PORT`, `FLASK_DEBUG`, and `LOG_LEVEL` environment variables. Debug mode is disabled unless `FLASK_DEBUG=1` is explicitly set.

## Routes

| Route | Purpose |
| --- | --- |
| `/` | Project homepage |
| `/heart` | Heart disease screening demo |
| `/diabetes` | Diabetes screening demo |
| `/liver` | Liver disease screening demo |
| `/breast` | Experimental breast-cancer pattern demo |
| `/model-performance` | Reported notebook metrics |
| `/health` | Application and model-load health check |

## Honest CV description

> Developed a responsive Flask-based educational health-classification application integrating four serialized ML models, server-side validation, confidence-aware results, performance visualization, privacy protections, deployment configuration, and automated tests.

Do not include accuracy claims on a CV until the training pipeline and evaluation can be reproduced.
